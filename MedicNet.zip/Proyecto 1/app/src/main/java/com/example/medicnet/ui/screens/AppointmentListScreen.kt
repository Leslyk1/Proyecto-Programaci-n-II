package com.example.medicnet.ui.screens

import android.app.DatePickerDialog
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.medicnet.viewmodel.AppointmentViewModel
import com.example.medicnet.data.model.Appointment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.tasks.await

import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi

enum class StatusFilter { ALL, SCHEDULED, RESCHEDULED, COMPLETED, CANCELED }

sealed class PendingAction {
    data class Complete(val id: String): PendingAction()
    data class Cancel(val id: String): PendingAction()
    data class Reschedule(val id: String): PendingAction()
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppointmentListScreen(
    vm: AppointmentViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    goToReschedule: (String) -> Unit = {}
) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db   = remember { FirebaseFirestore.getInstance() }
    val uid  = auth.currentUser?.uid.orEmpty()

    val items   by vm.items.collectAsState()
    val loading by vm.loading.collectAsState()
    val error   by vm.error.collectAsState()

    var fromDate by remember { mutableStateOf<String?>(null) }
    var toDate   by remember { mutableStateOf<String?>(null) }
    var asc      by remember { mutableStateOf(true) }
    var statusFilter by remember { mutableStateOf(StatusFilter.ALL) }

    var role by remember { mutableStateOf<String?>(null) }
    var patientQuery by remember { mutableStateOf("") }
    var doctorQuery  by remember { mutableStateOf("") }

    LaunchedEffect(uid) {
        db.collection("users").document(uid).get()
            .addOnSuccessListener { snap ->
                role = snap.getString("role") ?: "patient"
                when (role) {
                    "patient" -> patientQuery = uid
                    "doctor"  -> doctorQuery  = uid
                    else -> Unit
                }
            }
            .addOnFailureListener { role = "patient" }
    }

    var confirm by remember { mutableStateOf<PendingAction?>(null) }
    fun confirmTitle(pa: PendingAction) = when (pa) {
        is PendingAction.Complete   -> "¿Marcar cita como completada?"
        is PendingAction.Cancel     -> "¿Cancelar esta cita?"
        is PendingAction.Reschedule -> "¿Reprogramar esta cita?"
    }
    fun confirmBody(pa: PendingAction) = when (pa) {
        is PendingAction.Complete   -> "Esta acción actualizará el estado a COMPLETED."
        is PendingAction.Cancel     -> "Esta acción actualizará el estado a CANCELED."
        is PendingAction.Reschedule -> "Abriremos la pantalla de reprogramación."
    }
    if (confirm != null) {
        val pa = confirm!!
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(confirmTitle(pa)) },
            text  = { Text(confirmBody(pa)) },
            confirmButton = {
                TextButton(onClick = {
                    when (pa) {
                        is PendingAction.Complete   -> vm.markCompleted(pa.id) { }
                        is PendingAction.Cancel     -> vm.markCanceled(pa.id)  { }
                        is PendingAction.Reschedule -> goToReschedule(pa.id)
                    }
                    confirm = null
                }) { Text("Confirmar") }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) { Text("Cancelar") }
            }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Citas", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        Text("Filtros", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DateButton(label = "Desde", value = fromDate, onPick = { fromDate = it })
            DateButton(label = "Hasta", value = toDate, onPick = { toDate = it })
        }

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Orden:")
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = asc, onClick = { asc = true }, label = { Text("Ascendente") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = !asc, onClick = { asc = false }, label = { Text("Descendente") })
        }

        Spacer(Modifier.height(8.dp))
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = statusFilter == StatusFilter.ALL, onClick = { statusFilter = StatusFilter.ALL }, label = { Text("Todas") })
            FilterChip(selected = statusFilter == StatusFilter.SCHEDULED, onClick = { statusFilter = StatusFilter.SCHEDULED }, label = { Text("Programadas") })
            FilterChip(selected = statusFilter == StatusFilter.RESCHEDULED, onClick = { statusFilter = StatusFilter.RESCHEDULED }, label = { Text("Reprogramadas") })
            FilterChip(selected = statusFilter == StatusFilter.COMPLETED, onClick = { statusFilter = StatusFilter.COMPLETED }, label = { Text("Completadas") })
            FilterChip(selected = statusFilter == StatusFilter.CANCELED, onClick = { statusFilter = StatusFilter.CANCELED }, label = { Text("Canceladas") })
        }

        Spacer(Modifier.height(12.dp))

        val fromIsoRange = fromDate?.let { "${it}T00:00Z" }
        val toIsoRange   = toDate?.let   { "${it}T23:59Z" }


        if (role == "patient") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = patientQuery, onValueChange = {}, enabled = false,
                    label = { Text("patientUid") }, modifier = Modifier.weight(1f)
                )
                Button(onClick = {
                    if (fromIsoRange == null && toIsoRange == null) {
                        vm.loadForPatient(patientQuery)
                    } else {
                        vm.loadForPatientWithFilters(patientQuery, fromIsoRange, toIsoRange, asc)
                    }
                }) { Text("Cargar por paciente") }
                OutlinedButton(onClick = {
                    vm.clearAppointments()
                }) { Text("Limpiar") }
            }
        }


        if (role == "doctor") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = doctorQuery, onValueChange = {}, enabled = false,
                    label = { Text("doctorUid") }, modifier = Modifier.weight(1f)
                )
                Button(onClick = {
                    if (fromIsoRange == null && toIsoRange == null) {
                        vm.loadForDoctor(doctorQuery)
                    } else {
                        vm.loadForDoctorWithFilters(doctorQuery, fromIsoRange, toIsoRange, asc)
                    }
                }) { Text("Cargar por médico") }
                OutlinedButton(onClick = {
                    vm.clearAppointments()
                }) { Text("Limpiar") }
            }
        }


        if (role == "admin" || role == "secretary") {
            QueryCardRow(
                label = "Paciente (patientUid)",
                value = patientQuery,
                onValueChange = { patientQuery = it },
                onClickLoad = {
                    if (fromIsoRange == null && toIsoRange == null) {
                        vm.loadForPatient(patientQuery)
                    } else {
                        vm.loadForPatientWithFilters(patientQuery, fromIsoRange, toIsoRange, asc)
                    }
                },
                onClickClear = {
                    patientQuery = ""
                    vm.clearAppointments()
                }
            )
            Spacer(Modifier.height(10.dp))
            QueryCardRow(
                label = "Médico (doctorUid)",
                value = doctorQuery,
                onValueChange = { doctorQuery = it },
                onClickLoad = {
                    if (fromIsoRange == null && toIsoRange == null) {
                        vm.loadForDoctor(doctorQuery)
                    } else {
                        vm.loadForDoctorWithFilters(doctorQuery, fromIsoRange, toIsoRange, asc)
                    }
                },
                onClickClear = {
                    doctorQuery = ""
                    vm.clearAppointments()
                }
            )
        }

        if (loading) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator()
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(12.dp))

        val filtered = remember(items, statusFilter) {
            when (statusFilter) {
                StatusFilter.ALL         -> items
                StatusFilter.SCHEDULED   -> items.filter { it.status.equals("scheduled", true) }
                StatusFilter.RESCHEDULED -> items.filter { it.status.equals("rescheduled", true) }
                StatusFilter.COMPLETED   -> items.filter { it.status.equals("completed", true) }
                StatusFilter.CANCELED    -> items.filter { it.status.equals("canceled", true) }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = filtered,
                key = { it.docId ?: it.hashCode() }
            ) { a ->
                AppointmentCard(
                    a = a,
                    role = role,
                    currentUid = uid,
                    onConfirmComplete = { id -> id?.let { confirm = PendingAction.Complete(it) } },
                    onConfirmCancel   = { id -> id?.let { confirm = PendingAction.Cancel(it) } },
                    onConfirmResch    = { id -> id?.let { confirm = PendingAction.Reschedule(it) } }
                )
            }
        }
    }
}

@Composable
private fun DateButton(
    label: String,
    value: String?,
    onPick: (String?) -> Unit
) {
    val ctx = LocalContext.current
    val cal = Calendar.getInstance()
    fun openPicker() {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH)
        val d = cal.get(Calendar.DAY_OF_MONTH)
        DatePickerDialog(ctx, { _, yy, mm, dd ->
            onPick("%04d-%02d-%02d".format(yy, mm + 1, dd))
        }, y, m, d).show()
    }
    OutlinedButton(onClick = { openPicker() }) {
        Text(if (value.isNullOrBlank()) label else "$label: $value")
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppointmentCard(
    a: Appointment,
    role: String?,
    currentUid: String,
    onConfirmComplete: (String?) -> Unit,
    onConfirmCancel: (String?) -> Unit,
    onConfirmResch: (String?) -> Unit
) {
    val db = remember { FirebaseFirestore.getInstance() }
    var patientName by remember(a.patientUid) { mutableStateOf<String?>(null) }
    var doctorName  by remember(a.doctorUid)  { mutableStateOf<String?>(null) }
    LaunchedEffect(a.patientUid) { patientName = fetchUserName(db, a.patientUid) }
    LaunchedEffect(a.doctorUid)  { doctorName  = fetchUserName(db, a.doctorUid, isDoctor = true) }
    val prettyDate = remember(a.scheduledAtIso) { formatIsoPretty(a.scheduledAtIso) }

    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("ID: ${a.docId ?: ""}")
            val patientLine = buildString {
                append("Paciente: "); append(patientName ?: "—"); append("  ("); append(shortUid(a.patientUid)); append(")")
            }
            val doctorLine = buildString {
                append("Médico: "); append(doctorName ?: "—"); append("  ("); append(shortUid(a.doctorUid)); append(")")
            }
            Text(patientLine)
            Text(doctorLine)
            Text("Fecha/Hora: $prettyDate")
            Text("Motivo: ${a.reason}")
            Text("Estado: ${a.status}")
            Spacer(Modifier.height(8.dp))

            val isFuture = isFutureIso(a.scheduledAtIso)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (role == "admin" || role == "secretary" || role == "doctor") {
                    Button(onClick = { onConfirmResch(a.docId) }) { Text("Reprogramar") }
                    Button(onClick = { onConfirmComplete(a.docId) }) { Text("Marcar completada") }
                    Button(onClick = { onConfirmCancel(a.docId) })  { Text("Marcar cancelada") }
                }
                if (role == "patient" && a.patientUid == currentUid && isFuture) {
                    Button(onClick = { onConfirmCancel(a.docId) }) { Text("Cancelar") }
                }
            }
        }
    }
}

private fun isFutureIso(iso: String?): Boolean {
    if (iso.isNullOrBlank()) return false
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val target = java.time.Instant.parse(iso.fixZuluIfNeeded())
            val now = java.time.Instant.now()
            target.isAfter(now)
        } else {
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val d = runCatching { fmt.parse(iso.removeSuffix("Z")) }.getOrNull() ?: return false
            d.time > System.currentTimeMillis()
        }
    } catch (_: Throwable) { false }
}

private fun String.fixZuluIfNeeded(): String =
    if (endsWith("Z", ignoreCase = true)) this else this + "Z"

@Composable
private fun QueryCardRow(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    onClickLoad: () -> Unit,
    onClickClear: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(6.dp))
                TextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    placeholder = { Text("UID…") },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        disabledContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                        disabledIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                    )
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = onClickLoad,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    modifier = Modifier.widthIn(min = 140.dp)
                ) { Text("Cargar") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onClickClear,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    modifier = Modifier.widthIn(min = 140.dp)
                ) { Text("Limpiar") }
            }
        }
    }
}

private suspend fun fetchUserName(
    db: FirebaseFirestore,
    uid: String?,
    isDoctor: Boolean = false
): String? {
    uid ?: return null
    return try {
        val snap = db.collection("users").document(uid).get().await()
        snap.getString("displayName")
            ?: snap.getString("name")
            ?: snap.getString("fullName")
            ?: if (isDoctor) "Médico" else "Paciente"
    } catch (_: Exception) { null }
}

private fun shortUid(uid: String?, keep: Int = 4): String {
    if (uid.isNullOrBlank()) return "—"
    return if (uid.length <= keep * 2) uid else uid.take(keep) + "…" + uid.takeLast(keep)
}

private fun formatIsoPretty(iso: String?): String {
    if (iso.isNullOrBlank()) return "—"
    return try {
        val src = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val clean = iso.removeSuffix("Z")
        val date = src.parse(clean) ?: return iso
        val dst = SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.getDefault()).apply {
            timeZone = TimeZone.getDefault()
        }
        dst.format(date)
    } catch (_: Exception) {
        iso ?: "—"
    }
}
