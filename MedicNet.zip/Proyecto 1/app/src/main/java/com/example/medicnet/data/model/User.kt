package com.example.medicnet.data.model

data class User(
    val uid: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val nationalId: String = "",
    val role: String = "",
    val email: String = "",
    val mustResetPassword: Boolean = true
)
