package com.example.medicnet.ui.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.medicnet.ui.screens.*

object Routes {
    const val Login = "login"
    const val Register = "register"
    const val ForcePwdChange = "force_pwd_change"

    const val AdminHome = "admin_home"
    const val DoctorHome = "doctor_home"
    const val PatientHome = "patient_home"
    const val SecretaryHome = "secretary_home"

    const val PreRegister = "pre_register"

    const val Appointments = "appointments"
    const val AppointmentForm = "appointment_form"
    const val AppointmentReschedule = "appointment_reschedule"

    const val Diagnosis = "diagnosis"
    const val DiagnosisSearch = "diagnosis_search"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNav() {
    val nav = rememberNavController()
    val backEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backEntry?.destination?.route


    val topLevelPrefixes = setOf(
        Routes.Login,
        Routes.AdminHome,
        Routes.DoctorHome,
        Routes.PatientHome,
        Routes.SecretaryHome
    )

    val showBack = nav.previousBackStackEntry != null &&
            topLevelPrefixes.none { prefix ->
                currentRoute?.startsWith(prefix) == true
            }

    val title = when {
        currentRoute?.startsWith(Routes.Login) == true -> "Iniciar sesión"
        currentRoute?.startsWith(Routes.Register) == true -> "Crear cuenta"
        currentRoute?.startsWith(Routes.ForcePwdChange) == true -> "Cambiar contraseña"

        currentRoute?.startsWith(Routes.AdminHome) == true -> "Inicio (Admin)"
        currentRoute?.startsWith(Routes.SecretaryHome) == true -> "Inicio (Secretaría)"
        currentRoute?.startsWith(Routes.DoctorHome) == true -> "Inicio (Médico)"
        currentRoute?.startsWith(Routes.PatientHome) == true -> "Inicio (Paciente)"

        currentRoute?.startsWith(Routes.PreRegister) == true -> "Prerregistro"
        currentRoute?.startsWith(Routes.Appointments) == true -> "Citas"
        currentRoute?.startsWith(Routes.AppointmentForm) == true -> "Nueva cita"
        currentRoute?.startsWith(Routes.Diagnosis) == true -> "Diagnóstico"
        currentRoute?.startsWith(Routes.DiagnosisSearch) == true -> "Buscar diagnósticos"
        currentRoute?.startsWith(Routes.AppointmentReschedule) == true -> "Reprogramar cita"

        else -> "MedicNet"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (showBack) {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Regresar"
                            )
                        }
                    }
                },
                actions = {

                    if (currentRoute?.startsWith(Routes.DoctorHome) == true) {
                        TextButton(onClick = { nav.navigate(Routes.DiagnosisSearch) }) {
                            Text("Buscar diagn.")
                        }
                    }
                }
            )
        }
    ) { inner ->

        NavHost(
            navController = nav,
            startDestination = Routes.Login,
            modifier = Modifier.padding(inner)
        ) {


            composable(Routes.Login) {
                LoginScreen(
                    goToRegister = {
                        nav.navigate(Routes.Register)
                    },
                    goToForcePwd = { uid ->

                        nav.navigate("${Routes.ForcePwdChange}/$uid") {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    },
                    goToAdmin = { uid ->
                        nav.navigate("${Routes.AdminHome}/$uid") {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    },
                    goToSecretary = { uid ->
                        nav.navigate("${Routes.SecretaryHome}/$uid") {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    },
                    goToDoctor = { uid ->
                        nav.navigate("${Routes.DoctorHome}/$uid") {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    },
                    goToPatient = { uid ->
                        nav.navigate("${Routes.PatientHome}/$uid") {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    }
                )
            }

            composable(Routes.Register) {
                RegistrationScreen(
                    onRegistered = { nav.popBackStack() }
                )
            }


            composable(
                route = "${Routes.ForcePwdChange}/{uid}",
                arguments = listOf(
                    navArgument("uid") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val uid = backStackEntry.arguments?.getString("uid") ?: ""

                ForcePasswordChangeScreen(
                    uid = uid,
                    onFinished = { role ->

                        when (role) {
                            "admin" -> nav.navigate("${Routes.AdminHome}/$uid") {
                                popUpTo(Routes.Login) { inclusive = true }
                            }
                            "secretary" -> nav.navigate("${Routes.SecretaryHome}/$uid") {
                                popUpTo(Routes.Login) { inclusive = true }
                            }
                            "doctor" -> nav.navigate("${Routes.DoctorHome}/$uid") {
                                popUpTo(Routes.Login) { inclusive = true }
                            }
                            else -> nav.navigate("${Routes.PatientHome}/$uid") {
                                popUpTo(Routes.Login) { inclusive = true }
                            }
                        }
                    }
                )
            }




            composable(
                route = "${Routes.AdminHome}/{uid}",
                arguments = listOf(
                    navArgument("uid") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val uid = backStackEntry.arguments?.getString("uid") ?: ""

                AdminHomeScreen(
                    goToPreRegister     = { nav.navigate(Routes.PreRegister) },
                    goToAppointments    = { nav.navigate(Routes.Appointments) },
                    goToAppointmentForm = { nav.navigate(Routes.AppointmentForm) },
                    onSignedOut         = {

                        nav.navigate(Routes.Login) {
                            popUpTo(nav.graph.startDestinationId) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    }
                )
            }


            composable(
                route = "${Routes.SecretaryHome}/{uid}",
                arguments = listOf(
                    navArgument("uid") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val uid = backStackEntry.arguments?.getString("uid") ?: ""

                SecretaryHomeScreen(
                    goToPreRegister     = { nav.navigate(Routes.PreRegister) },
                    goToAppointments    = { nav.navigate(Routes.Appointments) },
                    goToAppointmentForm = { nav.navigate(Routes.AppointmentForm) },
                    onSignedOut         = {
                        nav.navigate(Routes.Login) {
                            popUpTo(nav.graph.startDestinationId) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    }
                )
            }


            composable(
                route = "${Routes.DoctorHome}/{uid}",
                arguments = listOf(
                    navArgument("uid") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val uid = backStackEntry.arguments?.getString("uid") ?: ""

                DoctorHomeScreen(
                    goToAppointments    = { nav.navigate(Routes.Appointments) },
                    goToAppointmentForm = { nav.navigate(Routes.AppointmentForm) },
                    goToDiagnosis       = { nav.navigate(Routes.Diagnosis) },
                    onSignOut           = {
                        nav.navigate(Routes.Login) {
                            popUpTo(nav.graph.startDestinationId) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    }
                )
            }


            composable(
                route = "${Routes.PatientHome}/{uid}",
                arguments = listOf(
                    navArgument("uid") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val uid = backStackEntry.arguments?.getString("uid") ?: ""

                PatientHomeScreen(
                    onSignOut        = {
                        nav.navigate(Routes.Login) {
                            popUpTo(nav.graph.startDestinationId) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    },
                    goToAppointments = { nav.navigate(Routes.Appointments) }
                )
            }


            composable(Routes.PreRegister) {
                AdminPreRegisterScreen()
            }


            composable(Routes.Appointments) {
                AppointmentListScreen(
                    goToReschedule = { id ->
                        nav.navigate("${Routes.AppointmentReschedule}/$id")
                    }
                )
            }

            composable(Routes.AppointmentForm) {
                AppointmentFormScreen(
                    onSaved = { nav.popBackStack() }
                )
            }

            composable(
                route = "${Routes.AppointmentReschedule}/{id}",
                arguments = listOf(
                    navArgument("id") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getString("id") ?: ""
                AppointmentRescheduleScreen(
                    appointmentId = id,
                    onDone = { nav.popBackStack() }
                )
            }


            composable(Routes.Diagnosis) {
                DiagnosisScreen()
            }

            composable(Routes.DiagnosisSearch) {
                DiagnosisSearchScreen()
            }
        }
    }
}
