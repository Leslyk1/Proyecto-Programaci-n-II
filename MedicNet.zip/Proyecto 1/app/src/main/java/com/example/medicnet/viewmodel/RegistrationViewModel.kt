package com.example.medicnet.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medicnet.data.model.PreRegistration
import com.example.medicnet.data.repo.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class RegistrationUiState(
    val loading: Boolean = false,
    val prereg: PreRegistration? = null,
    val error: String? = null,
    val success: Boolean = false
)

class RegistrationViewModel(
    private val repo: UserRepository = UserRepository()
) : ViewModel() {

    private val _ui = MutableStateFlow(RegistrationUiState())
    val ui: StateFlow<RegistrationUiState> = _ui

    fun checkCode(code: String) {
        _ui.value = _ui.value.copy(loading = true, error = null, prereg = null, success = false)
        viewModelScope.launch {
            try {
                val pr = repo.getPreRegistration(code)
                if (pr == null) {
                    _ui.value = RegistrationUiState(loading = false, error = "Código inválido o inactivo")
                } else {
                    _ui.value = RegistrationUiState(loading = false, prereg = pr)
                }
            } catch (e: Exception) {
                _ui.value = RegistrationUiState(loading = false, error = e.message ?: "Error leyendo prerregistro")
            }
        }
    }

    fun register(code: String, email: String, password: String) {
        val pr = _ui.value.prereg ?: run {
            _ui.value = _ui.value.copy(error = "Valida el código primero")
            return
        }
        _ui.value = _ui.value.copy(loading = true, error = null, success = false)
        viewModelScope.launch {
            try {
                repo.registerWithCode(code.trim(), email.trim(), password, pr)
                _ui.value = _ui.value.copy(loading = false, success = true)
            } catch (e: Exception) {
                _ui.value = _ui.value.copy(loading = false, error = e.message ?: "Error registrando usuario")
            }
        }
    }
}
