package com.example.medicnet.data.model

data class PreRegistration(
    val firstName: String = "",
    val lastName: String = "",
    val nationalId: String = "",
    val role: String = "",
    val active: Boolean = false
)