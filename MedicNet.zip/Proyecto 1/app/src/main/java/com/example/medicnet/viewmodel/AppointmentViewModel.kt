package com.example.medicnet.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medicnet.data.model.Appointment
import com.example.medicnet.data.repo.AppointmentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AppointmentViewModel(
    private val repo: AppointmentRepository = AppointmentRepository()
) : ViewModel() {

    private val _items = MutableStateFlow<List<Appointment>>(emptyList())
    val items: StateFlow<List<Appointment>> = _items

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error


    fun clearError() { _error.value = null }


    fun loadForPatient(patientUid: String) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.listByPatient(patientUid)
        }.onSuccess { _items.value = it }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }

    fun loadForDoctor(doctorUid: String) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.listByDoctor(doctorUid)
        }.onSuccess { _items.value = it }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }


    fun create(
        patientUid: String,
        doctorUid: String,
        iso: String,
        reason: String,
        onDone: () -> Unit
    ) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.create(patientUid, doctorUid, iso, reason)
        }.onSuccess {
            onDone()
        }.onFailure { _error.value = it.message }
        _loading.value = false
    }

    fun reschedule(id: String, newIso: String, onDone: () -> Unit) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.reschedule(id, newIso)
        }.onSuccess { onDone() }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }

    fun markCompleted(id: String, onDone: () -> Unit) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.updateStatus(id, "completed")
        }.onSuccess { onDone() }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }

    fun markCanceled(id: String, onDone: () -> Unit) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.updateStatus(id, "canceled")
        }.onSuccess { onDone() }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }


    fun cancelAsPatient(id: String, currentUid: String, onDone: () -> Unit) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.cancelByPatient(id, currentUid)
        }.onSuccess {
            onDone()
        }.onFailure {
            _error.value = it.message
        }
        _loading.value = false
    }


    fun loadForPatientWithFilters(
        patientUid: String,
        fromIso: String?,
        toIso: String?,
        asc: Boolean
    ) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.listByPatientInRange(patientUid, fromIso, toIso, asc)
        }.onSuccess { _items.value = it }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }

    fun loadForDoctorWithFilters(
        doctorUid: String,
        fromIso: String?,
        toIso: String?,
        asc: Boolean
    ) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.listByDoctorInRange(doctorUid, fromIso, toIso, asc)
        }.onSuccess { _items.value = it }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }


    fun loadMineByStatus(
        role: String,
        uid: String,
        status: String? = null,
        desc: Boolean = true
    ) = viewModelScope.launch {
        runCatching {
            _loading.value = true
            repo.listMineByStatus(role, uid, status, desc)
        }.onSuccess { _items.value = it }
            .onFailure { _error.value = it.message }
        _loading.value = false
    }

    fun fixOldIdFields(onDone: () -> Unit = {}) = viewModelScope.launch {
        runCatching {
            repo.removeIdFieldFromAllAppointmentsOnce()
        }.onSuccess {
            onDone()
        }.onFailure { e ->
            _error.value = e.localizedMessage ?: "Error corrigiendo IDs antiguos"
        }
    }
    fun removeIdsOnce() = viewModelScope.launch {
        runCatching { repo.removeIdFieldFromAllAppointmentsOnce() }
    }

    fun clearAppointments() {
        _items.value = emptyList()
        _error.value = null
    }
}
