package com.example.medicnet.data.model



import com.google.firebase.Timestamp


data class Diagnosis(
    val id: String? = null,
    val patientUid: String = "",
    val doctorUid: String = "",
    val appointmentId: String? = null,
    val symptoms: String = "",
    val suggestion: String = "",
    val createdAt: Timestamp = Timestamp.now()
)
