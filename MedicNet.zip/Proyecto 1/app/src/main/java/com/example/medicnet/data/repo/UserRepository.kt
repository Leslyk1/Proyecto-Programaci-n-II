package com.example.medicnet.data.repo


import com.example.medicnet.data.model.PreRegistration
import com.example.medicnet.data.model.User
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await


data class PreRegResult(
    val code: String,
    val tempEmail: String,
    val tempPassword: String
)

class UserRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {




    private fun randomCode8(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..8).map { chars.random() }.joinToString("")
    }


    private fun randomPass10(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#\$%"
        return (1..10).map { chars.random() }.joinToString("")
    }


    suspend fun createPreRegistration(
        firstName: String,
        lastName: String,
        nationalId: String,
        role: String
    ): PreRegResult {
        val code = randomCode8()
        val tempPassword = randomPass10()

        val emailBase = "${firstName.trim().lowercase()}.${lastName.trim().lowercase()}"
            .replace("\\s+".toRegex(), "")
        val tempEmail = "$emailBase+$code@demoapp.local"

        val doc = hashMapOf(
            "firstName" to firstName.trim(),
            "lastName" to lastName.trim(),
            "nationalId" to nationalId.trim(),
            "role" to role.trim(),
            "active" to true,
            "tempEmail" to tempEmail,
            "tempPassword" to tempPassword,
            "createdAt" to Timestamp.now()
        )

        db.collection("preregistrations").document(code).set(doc).await()
        return PreRegResult(code = code, tempEmail = tempEmail, tempPassword = tempPassword)
    }



    suspend fun getPreRegistration(code: String): PreRegistration? {
        if (code.isBlank()) return null
        val snap = db.collection("preregistrations").document(code).get().await()
        if (!snap.exists()) return null
        val data = snap.toObject(PreRegistration::class.java) ?: return null
        return if (data.active) data else null
    }


    suspend fun registerWithCode(
        code: String,
        email: String,
        password: String,
        prereg: PreRegistration
    ) {

        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val uid = result.user?.uid ?: throw Exception("No se pudo obtener UID")


        val userDoc = User(
            uid = uid,
            firstName = prereg.firstName,
            lastName = prereg.lastName,
            nationalId = prereg.nationalId,
            role = prereg.role,
            email = email,
            mustResetPassword = true
        )
        db.collection("users").document(uid).set(userDoc).await()


        db.collection("preregistrations").document(code).update("active", false).await()


        auth.signOut()
    }
}
