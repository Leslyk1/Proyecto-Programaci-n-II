package com.example.medicnet.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.medicnet.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun ForcePasswordChangeScreen(
    uid: String,
    onFinished: (role: String) -> Unit
) {
    val ctx = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()

    var pass1 by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {


        Spacer(Modifier.windowInsetsTopHeight(WindowInsets.statusBars))

        Text(
            text = stringResource(R.string.force_pwd_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(12.dp))

        Text(
            text = "Por seguridad, crea tu nueva contraseña para continuar.",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = pass1,
            onValueChange = { pass1 = it },
            label = { Text(stringResource(R.string.new_password)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = pass2,
            onValueChange = { pass2 = it },
            label = { Text(stringResource(R.string.confirm_password)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        Button(
            enabled = !loading,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                error = null


                if (pass1.isBlank() || pass2.isBlank()) {
                    error = "Llene ambos campos."
                    return@Button
                }
                if (pass1 != pass2) {
                    error = ctx.getString(R.string.passwords_not_match)
                    return@Button
                }
                if (pass1.length < 6) {

                    error = "La contraseña debe tener al menos 6 caracteres."
                    return@Button
                }

                val currentUser = auth.currentUser
                if (currentUser == null || currentUser.uid != uid) {

                    error = "Sesión no válida. Vuelva a iniciar sesión."
                    return@Button
                }


                loading = true
                scope.launch {
                    try {

                        currentUser.updatePassword(pass1).await()


                        val snap = db.collection("users")
                            .document(uid)
                            .get()
                            .await()

                        val role = (snap.getString("role") ?: "patient").trim()


                        db.collection("users")
                            .document(uid)
                            .update("mustResetPassword", false)
                            .await()


                        Toast.makeText(
                            ctx,
                            ctx.getString(R.string.password_updated),
                            Toast.LENGTH_LONG
                        ).show()


                        onFinished(role)

                    } catch (e: Exception) {
                        error = e.message ?: "Error actualizando contraseña"
                    } finally {
                        loading = false
                    }
                }
            }
        ) {
            if (loading) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Text(stringResource(R.string.change_password_btn))
            }
        }

        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
