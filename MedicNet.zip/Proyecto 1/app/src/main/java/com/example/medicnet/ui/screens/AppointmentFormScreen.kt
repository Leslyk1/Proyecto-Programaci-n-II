package com.example.medicnet.ui.screens



import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.medicnet.viewmodel.AppointmentViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentFormScreen(
    vm: AppointmentViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    onSaved: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth = remember { FirebaseAuth.getInstance() }
    val currentUid = auth.currentUser?.uid.orEmpty()

    // Campos básicos
    var patientUid by remember { mutableStateOf("") }
    var doctorUid  by remember { mutableStateOf(currentUid) }
    var reason     by remember { mutableStateOf("") }


    val todayUtc = remember { System.currentTimeMillis() }
    val dateState = rememberDatePickerState(
        initialSelectedDateMillis = todayUtc
    )
    var showDatePicker by remember { mutableStateOf(false) }


    var hour by remember { mutableStateOf(defaultNextHour()) }
    var minute by remember { mutableStateOf(0) }
    var showTimePicker by remember { mutableStateOf(false) }


    val dateLabel = remember(dateState.selectedDateMillis) {
        dateState.selectedDateMillis?.let { millis ->
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            df.timeZone = TimeZone.getDefault()
            df.format(Date(millis))
        } ?: "Seleccionar fecha"
    }
    val timeLabel = remember(hour, minute) {
        String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
    }


    val loading by vm.loading.collectAsState()
    val error   by vm.error.collectAsState()


    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Nueva cita", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = patientUid,
            onValueChange = { patientUid = it },
            label = { Text("UID del paciente") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = doctorUid,
            onValueChange = { doctorUid = it },
            label = { Text("UID del médico") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Motivo") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        Spacer(Modifier.height(16.dp))


        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showDatePicker = true }) {
                Text("Fecha: $dateLabel")
            }
            OutlinedButton(onClick = { showTimePicker = true }) {
                Text("Hora: $timeLabel")
            }
        }

        if (showDatePicker) {
            DatePickerDialog(
                onDismissRequest = { showDatePicker = false },
                confirmButton = {
                    TextButton(onClick = { showDatePicker = false }) { Text("OK") }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePicker = false }) { Text("Cancelar") }
                }
            ) {
                DatePicker(state = dateState)
            }
        }

        if (showTimePicker) {
            TimePickerDialog(
                ctx,
                { _, h, m ->
                    hour = h
                    minute = m
                    showTimePicker = false
                },
                hour,
                minute,
                true
            ).apply {
                setOnCancelListener { showTimePicker = false }
                show()
            }
        }

        Spacer(Modifier.height(16.dp))


        val selectedIso = remember(dateState.selectedDateMillis, hour, minute) {
            toUtcIso(dateState.selectedDateMillis, hour, minute)
        }
        Text("Se guardará como (UTC): $selectedIso", style = MaterialTheme.typography.bodySmall)

        Spacer(Modifier.height(16.dp))

        if (loading) {
            LinearProgressIndicator()
            Spacer(Modifier.height(12.dp))
        }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
        }

        Row {
            Button(
                onClick = {
                    if (patientUid.isBlank() || doctorUid.isBlank() || selectedIso == null || reason.isBlank()) {
                        Toast.makeText(ctx, "Completa todos los campos.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    scope.launch {
                        vm.create(
                            patientUid = patientUid.trim(),
                            doctorUid = doctorUid.trim(),
                            iso = selectedIso,
                            reason = reason.trim()
                        ) {
                            Toast.makeText(ctx, "Cita creada.", Toast.LENGTH_SHORT).show()
                            onSaved()
                        }
                    }
                }
            ) { Text("Crear") }

            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { patientUid = ""; reason = "" }) { Text("Limpiar") }
        }
    }
}


private fun defaultNextHour(): Int {
    val cal = Calendar.getInstance()
    val h = cal.get(Calendar.HOUR_OF_DAY)
    return (h + 1) % 24
}


private fun toUtcIso(dateMillis: Long?, hour: Int, minute: Int): String? {
    if (dateMillis == null) return null
    val local = Calendar.getInstance().apply {
        timeInMillis = dateMillis

        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }


    val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        timeInMillis = local.timeInMillis
    }
    val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    return fmt.format(Date(utc.timeInMillis))
}
