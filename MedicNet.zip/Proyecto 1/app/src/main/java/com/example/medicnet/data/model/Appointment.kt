package com.example.medicnet.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId

data class Appointment(
    @DocumentId val docId: String? = null,
    val patientUid: String = "",
    val doctorUid: String = "",

    val scheduledAtIso: String = "",
    val reason: String = "",
    val status: String = "scheduled",
    val paid: Boolean = false,
    val paymentId: String? = null,
    val amount: Double = 0.0,
    val currency: String = "GTQ",
    val createdAt: Timestamp? = null
)
