package com.example.medicnet.data.repo



import android.util.Log
import com.example.medicnet.BuildConfig
import com.example.medicnet.data.model.Diagnosis
import com.example.medicnet.data.remote.ChatMessage
import com.example.medicnet.data.remote.ChatRequest
import com.example.medicnet.data.remote.OpenAIRetrofit
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class DiagnosisRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val col = db.collection("diagnoses")


    private fun localRules(symptoms: String): String {
        val s = symptoms.lowercase()
        val notes = mutableListOf<String>()

        if (s.contains("fiebre") && s.contains("tos")) {
            notes += "Cuadro respiratorio febril; considere evaluación clínica, hidratación y vigilancia de signos de alarma."
        }
        if (s.contains("dolor") && s.contains("garganta")) {
            notes += "Odinofagia; sugerir medidas locales y valoración si persiste o empeora."
        }
        if (s.contains("cefalea") || s.contains("dolor de cabeza")) {
            notes += "Cefalea; indagar duración, intensidad y síntomas asociados; alarma si es súbita, severa, con rigidez de nuca o déficit neurológico."
        }
        if (s.contains("diarrea")) {
            notes += "Diarrea; vigilar hidratación, fiebre, sangre en heces y duración >48–72h."
        }
        if (s.contains("tos") && s.contains("disnea")) {
            notes += "Síntomas respiratorios con dificultad respiratoria: priorizar valoración presencial."
        }
        if (notes.isEmpty()) {
            notes += "Síntomas inespecíficos: se sugiere valoración clínica para diagnóstico diferencial."
        }

        return buildString {
            appendLine(notes.joinToString(" "))
            appendLine()
            append("La siguiente sugerencia es informativa y no sustituye el juicio clínico.")
        }
    }


    private fun buildPrompt(symptoms: String): String = """
        Eres un asistente médico educativo. No das tratamientos ni fármacos ni dosis.
        Objetivo: ofrecer un **diagnóstico diferencial orientativo** según los síntomas del usuario.

        Síntomas del paciente (texto libre):
        ${symptoms.trim()}

        Devuelve la salida **en español** y con este formato, sin texto adicional fuera de la estructura:

        1) Posibles diagnósticos (3–5):
           - Para cada uno: Nombre y probabilidad relativa (baja/media/alta) + justificación breve según los síntomas.
        2) Signos de alarma a vigilar (viñetas cortas).
        3) Recomendación breve (p. ej., “Consultar con profesional si persisten/agravan los síntomas”).

        Prohibido: prescribir fármacos o dosis.
        Cierra SIEMPRE con la frase literal:
        "La siguiente sugerencia es informativa y no sustituye el juicio clínico."
    """.trimIndent()


    suspend fun generateSuggestion(symptoms: String, useOpenAi: Boolean): String {
        val trimmed = symptoms.trim()
        if (trimmed.isEmpty()) return "Describe algunos síntomas para generar una sugerencia."

        val hasKey = BuildConfig.OPENAI_API_KEY.isNotBlank()


        if (!useOpenAi || !hasKey) {
            Log.d("AI", "Usando motor local (useOpenAi=$useOpenAi, hasKey=$hasKey)")
            val local = localRules(trimmed)
            return "📴[LOCAL]\n$local"
        }


        return try {
            val svc = OpenAIRetrofit.service()
            val res = svc.chatCompletions(
                OpenAIRetrofit.bearer(),
                ChatRequest(
                    model = "gpt-4o-mini",
                    temperature = 0.3,
                    messages = listOf(
                        ChatMessage(
                            role = "system",
                            content = "Eres un asistente médico educativo; no prescribes fármacos ni dosis."
                        ),
                        ChatMessage(role = "user", content = buildPrompt(trimmed))
                    )
                )
            )
            val txt = res.choices?.firstOrNull()?.message?.content?.trim().orEmpty()
            Log.d("AI", "Respuesta OpenAI len=${txt.length}")
            if (txt.isNotEmpty()) {
                "🔌[OPENAI]\n$txt"
            } else {
                val local = localRules(trimmed)
                "📴[LOCAL] (respuesta vacía de OpenAI)\n$local"
            }
        } catch (e: Exception) {
            val msg = e.message ?: "Error desconocido"
            Log.w("AI", "Fallo OpenAI: $msg")
            val local = localRules(trimmed)
            "📴[LOCAL] (falló OpenAI: $msg)\n$local"
        }
    }


    suspend fun create(d: Diagnosis): String {
        val ref = col.add(d.copy(id = null)).await()
        ref.update("id", ref.id).await()
        return ref.id
    }


    suspend fun listByPatient(patientUid: String): List<Diagnosis> {
        return runCatching {
            col.whereEqualTo("patientUid", patientUid)
                .orderBy("createdAt")
                .get().await()
        }.recoverCatching {
            col.whereEqualTo("patientUid", patientUid).get().await()
        }.getOrThrow()
            .documents.mapNotNull { it.toObject(Diagnosis::class.java) }
    }

    suspend fun listByDoctor(doctorUid: String): List<Diagnosis> {
        return runCatching {
            col.whereEqualTo("doctorUid", doctorUid)
                .orderBy("createdAt")
                .get().await()
        }.recoverCatching {
            col.whereEqualTo("doctorUid", doctorUid).get().await()
        }.getOrThrow()
            .documents.mapNotNull { it.toObject(Diagnosis::class.java) }
    }
}
