package com.example.medicnet.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.medicnet.BuildConfig
import com.example.medicnet.data.model.Diagnosis
import com.example.medicnet.data.repo.DiagnosisRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DiagnosisViewModel(
    private val repo: DiagnosisRepository = DiagnosisRepository()
) : ViewModel() {


    private val useOpenAi: Boolean = BuildConfig.OPENAI_API_KEY.isNotBlank()
    val usingOpenAI: Boolean get() = useOpenAi

    private val _items = MutableStateFlow<List<Diagnosis>>(emptyList())
    val items = _items.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()


    fun clearError() { _error.value = null }


    fun generateSuggestionAsync(symptoms: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            clearError()
            val input = symptoms.trim()
            if (input.isBlank()) {
                _error.value = "Escribe algunos síntomas para generar una sugerencia."
                return@launch
            }
            _loading.value = true
            runCatching {

                repo.generateSuggestion(input, useOpenAi)
            }.onSuccess { text ->
                onResult(text)
            }.onFailure { e ->
                _error.value = e.localizedMessage ?: "No se pudo generar la sugerencia."
            }
            _loading.value = false
        }
    }


    fun create(d: Diagnosis, onDone: () -> Unit) {
        viewModelScope.launch {
            clearError()
            _loading.value = true
            runCatching { repo.create(d) }
                .onSuccess { onDone() }
                .onFailure { _error.value = it.localizedMessage ?: "No se pudo guardar el diagnóstico." }
            _loading.value = false
        }
    }


    fun loadByPatient(patientUid: String) {
        viewModelScope.launch {
            clearError()
            _loading.value = true
            runCatching { repo.listByPatient(patientUid) }
                .onSuccess { _items.value = it }
                .onFailure { _error.value = it.localizedMessage ?: "No se pudo cargar la lista." }
            _loading.value = false
        }
    }


    fun loadByDoctor(doctorUid: String) {
        viewModelScope.launch {
            clearError()
            _loading.value = true
            runCatching { repo.listByDoctor(doctorUid) }
                .onSuccess { _items.value = it }
                .onFailure { _error.value = it.localizedMessage ?: "No se pudo cargar la lista." }
            _loading.value = false
        }
    }
}
