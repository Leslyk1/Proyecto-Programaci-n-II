package com.example.medicnet.ui.screens

import android.widget.Toast
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.medicnet.R
import com.example.medicnet.data.model.Diagnosis
import com.example.medicnet.viewmodel.DiagnosisViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun DiagnosisScreen(
    vm: DiagnosisViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val ctx = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val db   = remember { FirebaseFirestore.getInstance() }
    val currentUid = auth.currentUser?.uid.orEmpty()

    var role by remember { mutableStateOf<String?>(null) }

    var patientUid by remember { mutableStateOf("") }
    var appointmentId by remember { mutableStateOf("") }
    var symptoms by remember { mutableStateOf("") }
    var suggestion by remember { mutableStateOf("") }

    var saving by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(currentUid) {
        db.collection("users").document(currentUid).get()
            .addOnSuccessListener { snap -> role = snap.getString("role") ?: "patient" }
            .addOnFailureListener { role = "patient" }
    }

    fun clearForm() {
        patientUid = ""
        appointmentId = ""
        symptoms = ""
        suggestion = ""
        localError = null
    }

    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .imePadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = stringResource(R.string.diagnosis_title), style = MaterialTheme.typography.headlineSmall)

        if (role == null) {
            LinearProgressIndicator()
            return@Column
        }

        if (role != "doctor") {
            Text(
                text = "Esta pantalla es solo para médicos. Para consultar diagnósticos, usa la pantalla de búsqueda.",
                color = MaterialTheme.colorScheme.secondary
            )
            return@Column
        }

        Text(stringResource(R.string.patient_uid), style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = patientUid,
            onValueChange = { patientUid = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Text(stringResource(R.string.appointment_id), style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = appointmentId,
            onValueChange = { appointmentId = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Text(stringResource(R.string.symptoms), style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = symptoms,
            onValueChange = {
                symptoms = it
                suggestion = ""
            },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp),
            minLines = 4,
            maxLines = 8
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    suggestion = ""
                    vm.generateSuggestionAsync(symptoms) { s -> suggestion = s }
                },
                enabled = symptoms.isNotBlank()
            ) { Text(stringResource(R.string.generate)) }

            Button(
                onClick = {
                    if (patientUid.isBlank() || symptoms.isBlank()) {
                        Toast.makeText(ctx, R.string.error_missing_fields, Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (suggestion.isBlank()) {
                        vm.generateSuggestionAsync(symptoms) { s -> suggestion = s }
                        return@Button
                    }

                    saving = true
                    localError = null
                    val d = Diagnosis(
                        patientUid = patientUid.trim(),
                        doctorUid = currentUid,
                        appointmentId = appointmentId.trim().ifBlank { null },
                        symptoms = symptoms.trim(),
                        suggestion = suggestion.trim()
                    )
                    vm.create(d) {
                        saving = false
                        Toast.makeText(ctx, R.string.diagnosis_saved, Toast.LENGTH_SHORT).show()

                        patientUid = ""
                        appointmentId = ""
                        symptoms = ""
                    }
                },
                enabled = !saving
            ) { Text(if (saving) "Guardando..." else stringResource(R.string.save)) }

            OutlinedButton(onClick = { clearForm() }) { Text("Limpiar") }
        }

        localError?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        if (suggestion.isNotBlank()) {
            Text(stringResource(R.string.suggestion), style = MaterialTheme.typography.titleMedium)

            Text(suggestion)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.disclaimer), color = MaterialTheme.colorScheme.primary)
        }
    }
}
