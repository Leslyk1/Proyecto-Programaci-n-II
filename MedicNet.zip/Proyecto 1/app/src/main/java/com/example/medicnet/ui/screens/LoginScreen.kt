package com.example.medicnet.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.medicnet.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun LoginScreen(
    goToRegister: () -> Unit = {},


    goToForcePwd: (String) -> Unit = {},
    goToAdmin: (String) -> Unit = {},
    goToSecretary: (String) -> Unit = {},
    goToDoctor: (String) -> Unit = {},
    goToPatient: (String) -> Unit = {}
) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    val ctx = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }

    var loading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {


        Spacer(Modifier.windowInsetsTopHeight(WindowInsets.statusBars))

        Image(
            painter = painterResource(id = R.drawable.medic_net),
            contentDescription = stringResource(R.string.logo_content_desc),
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .size(220.dp)
        )

        Spacer(Modifier.height(16.dp))

        Text(
            text = stringResource(R.string.login_title),
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text(stringResource(R.string.email)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = pass,
            onValueChange = { pass = it },
            label = { Text(stringResource(R.string.password)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                errorMsg = null

                if (email.isBlank() || pass.isBlank()) {
                    errorMsg = ctx.getString(R.string.error_missing_fields)
                    return@Button
                }

                loading = true

                auth.signInWithEmailAndPassword(email.trim(), pass.trim())
                    .addOnCompleteListener { task ->
                        loading = false

                        if (task.isSuccessful) {

                            val uid = task.result?.user?.uid
                            if (uid == null) {
                                errorMsg = "No se pudo obtener el UID del usuario."
                                return@addOnCompleteListener
                            }

                            val db = FirebaseFirestore.getInstance()
                            db.collection("users").document(uid).get()
                                .addOnSuccessListener { snap ->
                                    if (!snap.exists()) {

                                        errorMsg =
                                            "Este usuario no tiene perfil en Firestore (users/$uid)."
                                        return@addOnSuccessListener
                                    }


                                    val mustReset =
                                        snap.getBoolean("mustResetPassword") ?: false

                                    if (mustReset) {

                                        goToForcePwd(uid)
                                        return@addOnSuccessListener
                                    }


                                    val role =
                                        (snap.getString("role") ?: "patient").trim()

                                    when (role) {
                                        "admin" -> {
                                            Toast.makeText(
                                                ctx,
                                                "Login OK (admin)",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            goToAdmin(uid)
                                        }

                                        "secretary" -> {
                                            Toast.makeText(
                                                ctx,
                                                "Login OK (secretaria)",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            goToSecretary(uid)
                                        }

                                        "doctor" -> {
                                            Toast.makeText(
                                                ctx,
                                                "Login OK (doctor)",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            goToDoctor(uid)
                                        }

                                        else -> {
                                            Toast.makeText(
                                                ctx,
                                                "Login OK (paciente)",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            goToPatient(uid)
                                        }
                                    }
                                }
                                .addOnFailureListener { e ->
                                    errorMsg = e.localizedMessage
                                        ?: ctx.getString(R.string.error_auth_failed)
                                }
                        } else {
                            errorMsg = task.exception?.localizedMessage
                                ?: ctx.getString(R.string.error_auth_failed)
                        }
                    }
            },
            enabled = !loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (loading) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Text(stringResource(R.string.login_btn))
            }
        }

        Spacer(Modifier.height(12.dp))

        errorMsg?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
        }

        TextButton(
            onClick = goToRegister,
            modifier = Modifier.align(Alignment.End)
        ) {
            Text(stringResource(R.string.go_register))
        }
    }
}
