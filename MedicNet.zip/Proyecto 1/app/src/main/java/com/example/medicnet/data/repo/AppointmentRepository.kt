package com.example.medicnet.data.repo



import com.example.medicnet.data.model.Appointment
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


class AppointmentRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private val col get() = db.collection("appointments")


    private fun isoToTimestamp(iso: String): Timestamp {
        val candidates = listOf(
            "yyyy-MM-dd'T'HH:mm",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ss"
        )
        for (pat in candidates) {
            try {
                val sdf = SimpleDateFormat(pat, Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                    isLenient = false
                }
                val d = sdf.parse(iso)
                if (d != null) return Timestamp(d)
            } catch (_: ParseException) {  }
        }

        return Timestamp.now()
    }


    suspend fun create(
        patientUid: String,
        doctorUid: String,
        scheduledAtIso: String,
        reason: String
    ) {
        val uid = auth.currentUser?.uid ?: error("No auth")
        val now = Timestamp.now()
        val startTs = isoToTimestamp(scheduledAtIso)

        val appt = hashMapOf(
            "patientUid" to patientUid,
            "doctorUid" to doctorUid,
            "scheduledAtIso" to scheduledAtIso,
            "start" to startTs,
            "reason" to reason,
            "status" to "scheduled",
            "createdBy" to uid,
            "createdAt" to now,
            "updatedAt" to now,
            "updatedBy" to uid
        )
        val ref = col.add(appt).await()

        ref.update("id", ref.id).await()
    }


    suspend fun listByPatient(patientUid: String): List<Appointment> {
        val q = col.whereEqualTo("patientUid", patientUid).get().await()
        return q.documents.mapNotNull { it.toObject(Appointment::class.java) }
    }

    suspend fun listByDoctor(doctorUid: String): List<Appointment> {
        val q = col.whereEqualTo("doctorUid", doctorUid).get().await()
        return q.documents.mapNotNull { it.toObject(Appointment::class.java) }
    }


    suspend fun reschedule(id: String, newIso: String) {
        val now = Timestamp.now()
        val newStart = isoToTimestamp(newIso)
        col.document(id).update(
            mapOf(
                "scheduledAtIso" to newIso,
                "start" to newStart,
                "status" to "rescheduled",
                "updatedAt" to now,
                "updatedBy" to (auth.currentUser?.uid ?: "")
            )
        ).await()
    }


    suspend fun updateStatus(id: String, newStatus: String) {
        val now = Timestamp.now()
        col.document(id).update(
            mapOf(
                "status" to newStatus,
                "updatedAt" to now,
                "updatedBy" to (auth.currentUser?.uid ?: "")
            )
        ).await()
    }


    suspend fun cancelByPatient(id: String, uid: String) {
        col.document(id).update(
            mapOf(
                "status" to "canceled",
                "updatedAt" to FieldValue.serverTimestamp(),
                "updatedBy" to uid
            )
        ).await()
    }


    suspend fun listByPatientInRange(
        patientUid: String,
        fromIso: String?,
        toIso: String?,
        asc: Boolean
    ): List<Appointment> {
        var q = col.whereEqualTo("patientUid", patientUid)
        if (!fromIso.isNullOrBlank()) q = q.whereGreaterThanOrEqualTo("scheduledAtIso", fromIso)
        if (!toIso.isNullOrBlank())   q = q.whereLessThanOrEqualTo("scheduledAtIso", toIso)
        q = if (asc) q.orderBy("scheduledAtIso") else q.orderBy(
            "scheduledAtIso",
            Query.Direction.DESCENDING
        )
        val s = q.get().await()
        return s.documents.mapNotNull { it.toObject(Appointment::class.java) }
    }

    suspend fun listByDoctorInRange(
        doctorUid: String,
        fromIso: String?,
        toIso: String?,
        asc: Boolean
    ): List<Appointment> {
        var q = col.whereEqualTo("doctorUid", doctorUid)
        if (!fromIso.isNullOrBlank()) q = q.whereGreaterThanOrEqualTo("scheduledAtIso", fromIso)
        if (!toIso.isNullOrBlank())   q = q.whereLessThanOrEqualTo("scheduledAtIso", toIso)
        q = if (asc) q.orderBy("scheduledAtIso") else q.orderBy(
            "scheduledAtIso",
            Query.Direction.DESCENDING
        )
        val s = q.get().await()
        return s.documents.mapNotNull { it.toObject(Appointment::class.java) }
    }


    suspend fun listMineByStatus(
        role: String,
        uid: String,
        status: String? = null,
        desc: Boolean = true
    ): List<Appointment> {
        var q = when (role) {
            "patient"  -> col.whereEqualTo("patientUid", uid)
            "doctor"   -> col.whereEqualTo("doctorUid", uid)
            else       -> col
        }
        if (status != null) q = q.whereEqualTo("status", status)
        q = if (desc) q.orderBy("start", Query.Direction.DESCENDING) else q.orderBy("start")
        val s = q.get().await()
        return s.documents.mapNotNull { it.toObject(Appointment::class.java) }
    }


    suspend fun removeIdFieldFromAllAppointmentsOnce() {

        val snap = db.collection("appointments").get().await()
        for (doc in snap.documents) {

            if (doc.contains("id")) {
                db.collection("appointments").document(doc.id)
                    .update(mapOf("id" to FieldValue.delete()))
                    .await()
            }

        }
        suspend fun removeIdFieldFromAllAppointmentsOnce() {
            val snap = db.collection("appointments").get().await()
            for (doc in snap.documents) {
                if (doc.get("id") != null) {
                    db.collection("appointments").document(doc.id)
                        .update(mapOf("id" to FieldValue.delete()))
                        .await()
                }
            }
        }
    }
}

