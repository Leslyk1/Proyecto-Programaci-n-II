package com.example.medicnet.ui.screens


import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.medicnet.R
import com.example.medicnet.viewmodel.RegistrationViewModel

@Composable
fun RegistrationScreen( onRegistered: () -> Unit = {})
{
    var code by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    val vm: RegistrationViewModel = viewModel()
    val ui = vm.ui.collectAsState().value
    val ctx = LocalContext.current

    LaunchedEffect(ui.success) {
        if (ui.success) {
            Toast.makeText(ctx, ctx.getString(R.string.register_ok), Toast.LENGTH_LONG).show()

        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {


        Spacer(Modifier.windowInsetsTopHeight(WindowInsets.statusBars))

        Text(stringResource(R.string.register_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = code, onValueChange = { code = it },
            label = { Text(stringResource(R.string.prereg_code)) },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text(stringResource(R.string.email)) },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = pass, onValueChange = { pass = it },
            label = { Text(stringResource(R.string.password)) },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                if (code.isBlank() || email.isBlank() || pass.isBlank()) {
                    Toast.makeText(ctx, ctx.getString(R.string.error_missing_fields), Toast.LENGTH_SHORT).show()
                } else if (ui.prereg == null) {
                    vm.checkCode(code.trim())
                } else {
                    vm.register(code.trim(), email.trim(), pass)
                }
            },
            enabled = !ui.loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (ui.loading) {
                CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            } else {
                Text(stringResource(R.string.register_btn))
            }
        }

        ui.error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        ui.prereg?.let {
            Spacer(Modifier.height(12.dp))
            Text("Código válido para: ${it.firstName} ${it.lastName} (${it.role})")
        }
    }
}

