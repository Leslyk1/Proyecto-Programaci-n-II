package com.example.medicnet.ui.screens


import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.medicnet.viewmodel.AppointmentViewModel
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

@Composable
fun AppointmentRescheduleScreen(
    appointmentId: String,
    onDone: () -> Unit,
    vm: AppointmentViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val ctx = LocalContext.current


    val loading by vm.loading.collectAsState()
    val error   by vm.error.collectAsState()


    val cal = remember { Calendar.getInstance(TimeZone.getTimeZone("UTC")) }


    var loadedOnce by remember { mutableStateOf(false) }
    var currentIso by remember { mutableStateOf<String?>(null) }


    var chosenDateText by remember { mutableStateOf("") }
    var chosenTimeText by remember { mutableStateOf("") }


    LaunchedEffect(appointmentId) {
        if (appointmentId.isBlank()) return@LaunchedEffect
        FirebaseFirestore.getInstance()
            .collection("appointments").document(appointmentId)
            .get()
            .addOnSuccessListener { snap ->
                val iso = snap.getString("scheduledAtIso")
                currentIso = iso
                if (!loadedOnce && !iso.isNullOrBlank()) {
                    val (y, m, d, hh, mm) = parseIsoToParts(iso)
                    cal.set(Calendar.YEAR, y)
                    cal.set(Calendar.MONTH, m - 1)
                    cal.set(Calendar.DAY_OF_MONTH, d)
                    cal.set(Calendar.HOUR_OF_DAY, hh)
                    cal.set(Calendar.MINUTE, mm)
                    chosenDateText = "%04d-%02d-%02d".format(y, m, d)
                    chosenTimeText = "%02d:%02d".format(hh, mm)
                    loadedOnce = true
                }
            }
    }


    val openDatePicker = {
        val year  = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH)
        val day   = cal.get(Calendar.DAY_OF_MONTH)
        DatePickerDialog(
            ctx,
            { _, y, m, d ->
                cal.set(Calendar.YEAR, y)
                cal.set(Calendar.MONTH, m)
                cal.set(Calendar.DAY_OF_MONTH, d)
                chosenDateText = "%04d-%02d-%02d".format(y, m + 1, d)
            },
            year, month, day
        ).show()
    }

    val openTimePicker = {
        val hh = cal.get(Calendar.HOUR_OF_DAY)
        val mm = cal.get(Calendar.MINUTE)
        TimePickerDialog(
            ctx,
            { _, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                chosenTimeText = "%02d:%02d".format(hour, minute)
            },
            hh, mm, true
        ).show()
    }

    fun buildIsoUtc(): String? {
        if (chosenDateText.isBlank() || chosenTimeText.isBlank()) return null

        return "${chosenDateText}T${chosenTimeText}Z"
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text("Reprogramar cita", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("ID: $appointmentId", style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(16.dp))


        currentIso?.let { iso ->
            val (dNice, tNice) = prettyDateTimeFromIso(iso, useLocalTimeZone = true)
            Text("Programada actualmente:", fontWeight = FontWeight.SemiBold)
            Text("Fecha: $dNice")
            Text("Hora:  $tNice")
            Spacer(Modifier.height(8.dp))
        }


        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Nueva fecha y hora", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = openDatePicker) { Text("Elegir fecha") }
                    Text(chosenDateText.ifBlank { "—" })
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = openTimePicker) { Text("Elegir hora") }
                    Text(chosenTimeText.ifBlank { "—" })
                }

                Spacer(Modifier.height(12.dp))


                val previewIso = buildIsoUtc().orEmpty()
                if (previewIso.isBlank()) {
                    Text("Previsualización: Selecciona fecha y hora")
                } else {
                    val (dNice, tNice) = prettyDateTimeFromIso(previewIso, useLocalTimeZone = true)
                    Text("Previsualización:")
                    Text("Fecha: $dNice")
                    Text("Hora:  $tNice")
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                val iso = buildIsoUtc()
                if (iso == null) {
                    Toast.makeText(ctx, "Selecciona fecha y hora", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                vm.reschedule(appointmentId, iso) {
                    Toast.makeText(ctx, "Cita reprogramada", Toast.LENGTH_SHORT).show()
                    onDone()
                }
            },
            enabled = !loading && chosenDateText.isNotBlank() && chosenTimeText.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (loading) {
                CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            } else {
                Text("Guardar reprogramación")
            }
        }

        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
    }
}


private fun parseIsoToParts(iso: String): IsoParts {
    val cleaned = if (iso.endsWith("Z", true)) iso.dropLast(1) else iso
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val d = sdf.parse(cleaned)!!
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { time = d }
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val hh = cal.get(Calendar.HOUR_OF_DAY)
        val mm = cal.get(Calendar.MINUTE)
        IsoParts(y, m, day, hh, mm)
    } catch (_: Throwable) {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        IsoParts(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH),
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE)
        )
    }
}

private data class IsoParts(
    val year: Int,
    val month: Int,
    val day: Int,
    val hour: Int,
    val minute: Int
)


private fun parseIsoUtc(iso: String): java.util.Date? {
    val cleaned = if (iso.endsWith("Z", ignoreCase = true)) iso.dropLast(1) else iso
    return runCatching {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        sdf.parse(cleaned)
    }.getOrNull()
}


private fun prettyDateTimeFromIso(
    iso: String,
    useLocalTimeZone: Boolean = true
): Pair<String, String> {
    val d = parseIsoUtc(iso) ?: return "--" to "--"
    val tz = if (useLocalTimeZone) TimeZone.getDefault()
    else TimeZone.getTimeZone("UTC")
    val dfDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).apply { timeZone = tz }
    val dfTime = SimpleDateFormat("HH:mm",       Locale.getDefault()).apply { timeZone = tz }
    return dfDate.format(d) to dfTime.format(d)
}
