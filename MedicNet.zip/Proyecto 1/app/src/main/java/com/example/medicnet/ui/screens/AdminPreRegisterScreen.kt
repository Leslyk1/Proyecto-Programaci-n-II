package com.example.medicnet.ui.screens


import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.medicnet.R
import com.example.medicnet.data.repo.UserRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@Composable
fun AdminPreRegisterScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { UserRepository(FirebaseFirestore.getInstance(), FirebaseAuth.getInstance()) }

    var first by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var docId by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("patient") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var code by remember { mutableStateOf<String?>(null) }
    var tempEmail by remember { mutableStateOf<String?>(null) }
    var tempPass by remember { mutableStateOf<String?>(null) }

    fun copy(text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("copy", text))
        Toast.makeText(ctx, ctx.getString(R.string.copied), Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {


        Spacer(Modifier.windowInsetsTopHeight(WindowInsets.statusBars))

        Text(stringResource(R.string.pre_title), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(value = first, onValueChange = { first = it },
            label = { Text(stringResource(R.string.first_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(value = last, onValueChange = { last = it },
            label = { Text(stringResource(R.string.last_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(value = docId, onValueChange = { docId = it },
            label = { Text(stringResource(R.string.national_id)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))


        Row {
            FilterChip(
                selected = role == "patient",
                onClick = { role = "patient" },
                label = { Text(stringResource(R.string.role_patient)) }
            )
            Spacer(Modifier.width(8.dp))
            FilterChip(
                selected = role == "doctor",
                onClick = { role = "doctor" },
                label = { Text(stringResource(R.string.role_doctor)) }
            )
        }
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                error = null
                if (first.isBlank() || last.isBlank() || docId.isBlank()) {
                    error = ctx.getString(R.string.error_missing_fields)
                    return@Button
                }
                loading = true
                scope.launch {
                    try {
                        val res = repo.createPreRegistration(first, last, docId, role)
                        code = res.code; tempEmail = res.tempEmail; tempPass = res.tempPassword
                    } catch (e: Exception) {
                        error = e.message ?: "Error creando prerregistro"
                    } finally {
                        loading = false
                    }
                }
            },
            enabled = !loading
        ) {
            if (loading) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            else Text(stringResource(R.string.pre_create_btn))
        }

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        code?.let { c ->
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.pre_result_title), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${stringResource(R.string.pre_code)}: $c")
                TextButton(onClick = { copy(c) }) { Text(stringResource(R.string.copy)) }
            }
            tempEmail?.let { e ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${stringResource(R.string.pre_temp_email)}: $e")
                    TextButton(onClick = { copy(e) }) { Text(stringResource(R.string.copy)) }
                }
            }
            tempPass?.let { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${stringResource(R.string.pre_temp_pass)}: $p")
                    TextButton(onClick = { copy(p) }) { Text(stringResource(R.string.copy)) }
                }
            }
        }
    }
}
