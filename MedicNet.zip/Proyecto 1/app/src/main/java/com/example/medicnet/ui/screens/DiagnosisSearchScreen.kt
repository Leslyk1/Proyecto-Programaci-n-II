package com.example.medicnet.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

data class DiagnosisItem(
    val docId: String,
    val patientUid: String,
    val doctorUid: String?,
    val appointmentId: String?,
    val symptoms: String?,
    val suggestion: String?,
    val createdAt: Timestamp?
)

@Composable
fun DiagnosisSearchScreen() {
    val db = remember { FirebaseFirestore.getInstance() }
    val auth = remember { FirebaseAuth.getInstance() }
    val scope = rememberCoroutineScope()
    val currentUid = auth.currentUser?.uid.orEmpty()


    var role by remember { mutableStateOf<String?>(null) }
    var patientUid by remember { mutableStateOf("") }
    var fromDate by remember { mutableStateOf<String?>(null) }
    var toDate   by remember { mutableStateOf<String?>(null) }
    var asc      by remember { mutableStateOf(true) }

    var items by remember { mutableStateOf<List<DiagnosisItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }


    LaunchedEffect(currentUid) {
        db.collection("users").document(currentUid).get()
            .addOnSuccessListener { snap -> role = snap.getString("role") ?: "patient" }
            .addOnFailureListener { role = "patient" }
    }

    fun clearAll() {
        items = emptyList()
        patientUid = ""
        fromDate = null
        toDate = null
        error = null
    }

    fun search() = scope.launch {
        if (patientUid.isBlank()) {
            error = "Ingresa un UID de paciente."
            return@launch
        }
        loading = true
        error = null
        try {
            var q: Query = db.collection("diagnoses")
                .whereEqualTo("patientUid", patientUid.trim())


            if (role == "doctor") {
                q = q.whereEqualTo("doctorUid", currentUid)
            }


            if (fromDate != null) q = q.whereGreaterThanOrEqualTo("createdAt", dayBoundary(fromDate!!, false))
            if (toDate   != null) q = q.whereLessThanOrEqualTo("createdAt",  dayBoundary(toDate!!, true))


            q = q.orderBy("createdAt", if (asc) Query.Direction.ASCENDING else Query.Direction.DESCENDING)

            val snap = q.get().await()
            items = snap.documents.map { d ->
                DiagnosisItem(
                    docId = d.id,
                    patientUid = d.getString("patientUid") ?: "",
                    doctorUid = d.getString("doctorUid"),
                    appointmentId = d.getString("appointmentId"),
                    symptoms = d.getString("symptoms"),
                    suggestion = d.getString("suggestion"),
                    createdAt = d.getTimestamp("createdAt")
                )
            }
        } catch (e: Exception) {
            error = e.message ?: "Error al buscar."
        } finally {
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Buscar diagnósticos", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = patientUid,
            onValueChange = { patientUid = it },
            label = { Text("UID de paciente") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DateButton(label = "Desde", value = fromDate, onPick = { fromDate = it })
            DateButton(label = "Hasta", value = toDate, onPick = { toDate = it })
        }

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Orden:")
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = asc, onClick = { asc = true }, label = { Text("Ascendente") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = !asc, onClick = { asc = false }, label = { Text("Descendente") })
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { search() }, enabled = role != null) { Text("Buscar") }
            OutlinedButton(onClick = { clearAll() }) { Text("Limpiar") }
        }

        if (loading) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator() }
        error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MaterialTheme.colorScheme.error) }

        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.docId }) { di -> DiagnosisCard(di) }
        }
    }
}

@Composable
private fun DiagnosisCard(di: DiagnosisItem) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("ID: ${di.docId}")
            Text("Paciente: ${shortUid(di.patientUid)}")
            Text("Médico: ${shortUid(di.doctorUid)}")
            di.appointmentId?.takeUnless { it.isBlank() }?.let { Text("Cita: ${shortUid(it)}") }
            Text("Síntomas: ${di.symptoms ?: "—"}")
            Text("Sugerencia: ${di.suggestion ?: "—"}")
            Text("Creado: ${formatTimestamp(di.createdAt)}")
        }
    }
}

private fun formatTimestamp(ts: Timestamp?): String {
    ts ?: return "—"
    val date = ts.toDate()
    val fmt = SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.getDefault())
    return fmt.format(date)
}

private fun shortUid(uid: String?, keep: Int = 4): String {
    uid ?: return "—"
    return if (uid.length <= keep * 2) uid else uid.take(keep) + "…" + uid.takeLast(keep)
}

@Composable
private fun DateButton(label: String, value: String?, onPick: (String?) -> Unit) {
    val ctx = LocalContext.current
    val cal = Calendar.getInstance()
    fun openPicker() {
        val y = cal.get(Calendar.YEAR); val m = cal.get(Calendar.MONTH); val d = cal.get(Calendar.DAY_OF_MONTH)
        DatePickerDialog(ctx, { _, yy, mm, dd ->
            onPick("%04d-%02d-%02d".format(yy, mm + 1, dd))
        }, y, m, d).show()
    }
    OutlinedButton(onClick = { openPicker() }) {
        Text(if (value.isNullOrBlank()) label else "$label: $value")
    }
}

private fun dayBoundary(date: String, endOfDay: Boolean): Timestamp {
    val parts = date.split("-").map { it.toInt() }
    val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        set(Calendar.YEAR, parts[0]); set(Calendar.MONTH, parts[1] - 1); set(Calendar.DAY_OF_MONTH, parts[2])
        if (endOfDay) { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
        else { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    }
    return Timestamp(cal.time)
}
